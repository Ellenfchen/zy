# Video
## ZY player网络接口
国内访问地址一
```
https://raw.iqiq.io/2hacc/Video/main/zy.json
```
国内访问地址二
```
https://raw.fastgit.org/2hacc/Video/main/zy.json
```
国内访问备用地址一
```
https://cdn.jsdelivr.net/gh/2hacc/Video@main/zy.json
```
国内访问备用地址二
```
https://raw.githubusercontents.com/2hacc/Video/main/zy.json
```
国内访问备用地址三
```
https://ghproxy.com/https://raw.githubusercontent.com/2hacc/Video/main/zy.json
